time ../bin/FRaC -E res/uci/iris -M 2 -N 0 -S 0
time ../bin/FRaC -E res/uci/car -M 2 -N 8 -S 0
time ../bin/FRaC -E res/uci/ecoli -M 2 -N 0 -S 0
